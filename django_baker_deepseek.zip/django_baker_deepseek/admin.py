from django.core.validators import URLValidator
from django.core.exceptions import FieldDoesNotExist
from django.utils.encoding import force_str
from django.utils.html import format_html
from django.db.models import ForeignKey, OneToOneField, URLField
from functools import partial


def number_field_choices(field):
    """Return the number of choices for a field."""
    try:
        return len(field.get_flat_choices())
    except AttributeError:
        return 0


def remove_duplicates(seq, key=None):
    """Remove duplicates from list while preserving order."""
    seen = set()
    result = []
    for item in seq:
        item_key = key(item) if key else item
        if item_key not in seen:
            seen.add(item_key)
            result.append(item)
    return result


def is_urlfield(field, model=None):
    """Check if a field is a URLField."""
    if model:
        try:
            field = model._meta.get_field(field)
        except FieldDoesNotExist:
            return False
    
    return isinstance(field, URLField)


def is_foreignkey(field_name, model):
    """Check if a field is ForeignKey or OneToOneField."""
    try:
        field = model._meta.get_field(field_name)
        return isinstance(field, (ForeignKey, OneToOneField))
    except FieldDoesNotExist:
        return False


class ExtendedModelAdminMixin:
    """
    Model Admin Mixin that makes intelligent choices to minimize admin setup time.
    """
    extra_list_display = []
    extra_list_filter = []
    extra_search_fields = []
    link_url_fields = True
    link_foreign_key_fields = True
    max_related_objects = 100
    list_all_select_related = True
    filter_by_field_types = ["BooleanField", "CharField", "IntegerField", "DateField", "DateTimeField"]
    search_by_field_types = ["CharField", "TextField"]

    def __getattr__(self, name):
        """Dynamically create methods for URL and foreign key field links."""
        if name.startswith('url_link_'):
            field_name = name[9:]
            
            def url_link_method(instance):
                target = getattr(instance, field_name, None)
                if not target:
                    return ""
                return format_html('<a href="{}" target="_blank" rel="noopener noreferrer">{}</a>', target, target)
            
            url_link_method.short_description = field_name.replace('_', ' ').title()
            url_link_method.admin_order_field = field_name
            setattr(self, name, url_link_method)
            return getattr(self, name)

        elif name.startswith('fk_link_'):
            field_name = name[8:]
            
            def fk_link_method(instance):
                target = getattr(instance, field_name, None)
                if not target:
                    return "None"
                
                app_label = target._meta.app_label
                model_name = target._meta.model_name
                pk_value = getattr(target, target._meta.pk.name)
                
                return format_html(
                    '<a href="/admin/{}/{}/{}/change/">{}</a>',
                    app_label, model_name, pk_value, force_str(target)
                )
            
            fk_link_method.short_description = field_name.replace('_', ' ').title()
            fk_link_method.admin_order_field = field_name
            setattr(self, name, fk_link_method)
            return getattr(self, name)

        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def __init__(self, model, admin_site):
        """Initialize the admin with optimized settings."""
        super().__init__(model, admin_site)
        
        # Auto-configure list_display
        if not self.list_display or self.list_display == ('__str__',):
            self.list_display = self._get_auto_list_display()
        
        # Auto-configure list_filter
        if not self.list_filter:
            self.list_filter = self._get_auto_list_filter()
        
        # Auto-configure search_fields
        if not self.search_fields:
            self.search_fields = self._get_auto_search_fields()
        
        # Configure select_related for performance
        if self.list_all_select_related:
            self.select_related = self._get_select_related_fields()

    def _get_auto_list_display(self):
        """Generate automatic list_display fields."""
        fields = []
        
        # Add primary key if it's not auto-generated
        pk_field = self.model._meta.pk
        if not pk_field.auto_created:
            fields.append(pk_field.name)
        
        # Add relevant fields
        for field in self.model._meta.fields:
            if field.name in ['created_at', 'updated_at', 'modified_at']:
                fields.append(field.name)
            elif field.get_internal_type() in ['CharField', 'TextField', 'EmailField']:
                fields.append(field.name)
            elif isinstance(field, (ForeignKey, OneToOneField)):
                fields.append(field.name)
        
        # Add URL and FK link methods
        for field in self.model._meta.fields:
            if self.link_url_fields and is_urlfield(field):
                fields.append(f'url_link_{field.name}')
            elif (self.link_foreign_key_fields and 
                  isinstance(field, (ForeignKey, OneToOneField))):
                fields.append(f'fk_link_{field.name}')
        
        return remove_duplicates(fields + self.extra_list_display)

    def _get_auto_list_filter(self):
        """Generate automatic list_filter fields."""
        filters = []
        
        for field in self.model._meta.fields:
            if field.get_internal_type() in self.filter_by_field_types:
                filters.append(field.name)
            elif isinstance(field, (ForeignKey, OneToOneField)):
                # Only add if the related model has a reasonable number of objects
                related_model = field.related_model
                if related_model._default_manager.count() <= self.max_related_objects:
                    filters.append(field.name)
        
        return remove_duplicates(filters + self.extra_list_filter)

    def _get_auto_search_fields(self):
        """Generate automatic search_fields."""
        search_fields = []
        
        for field in self.model._meta.fields:
            if field.get_internal_type() in self.search_by_field_types:
                search_fields.append(field.name)
        
        return remove_duplicates(search_fields + self.extra_search_fields)

    def _get_select_related_fields(self):
        """Get all foreign key fields for select_related optimization."""
        return [field.name for field in self.model._meta.fields 
                if isinstance(field, (ForeignKey, OneToOneField))]