from django.apps import AppConfig


class DjangoBakerDeepseekConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_baker_deepseek'
