import os
import re
from django.db.models import SlugField
from django.template.loader import get_template
from django.apps import apps
from django.utils.encoding import force_str

# Add type hints and modern Python features
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path

from .config import BakerConfig, get_default_config  # ← Import from config

class Baker:
    """
    Given a dictionary of apps and models, Baker will generate files that help
    get your new Django app up and running quickly.
    """

    def __init__(self, force=False, dry_run=False):
        self.force = force
        self.dry_run = dry_run

    def bake(self, apps_and_models):
        """
        Iterates through a dictionary of apps and models and creates all the
        necessary files to get up and running quickly.
        """
        for app_label, models_app in apps_and_models.items():
            models, app = models_app
            models = list(models)
            model_names = {
                model.__name__: self.get_field_names_for_model(model) 
                for model in models
            }
            self.create_directories(app)
            self.create_init_files(app, model_names.keys(), models)
            self.remove_empty_startapp_files(app)
            
            for file_name in ["forms", "admin"]:
                file_path = Path(app.path) / f"{file_name}.py"
                template_path = f"django_baker_deepseek/{file_name}"  # Fixed path
                self.create_file_from_template(
                    file_path, template_path, {"model_names": model_names}
                )
            
            for model in models:
                model_attributes = self.model_attributes(app, model)
                self.create_files_from_templates(model_attributes)

    # def get_field_names_for_model(self, model):
    #     """
    #     Returns fields other than id and uneditable fields.
    #     """
    #     return [
    #         field.name for field in model._meta.get_fields()
    #         if (field.name != "id" and 
    #             not (hasattr(field, 'auto_now') and field.auto_now) and
    #             not (hasattr(field, 'auto_now_add') and field.auto_now_add) and
    #             field.concrete and 
    #             (not field.is_relation or field.one_to_one or 
    #              (field.many_to_one and field.related_model)))
    #     ]

    def get_field_names_for_model(self, model) -> List[str]:
        """Get editable field names excluding read-only and relation fields."""
        return [
            field.name for field in model._meta.get_fields()
            if (field.concrete and 
                not field.auto_created and
                not (hasattr(field, 'auto_now') and field.auto_now) and
                not (hasattr(field, 'auto_now_add') and field.auto_now_add) and
                field.editable and
                not field.is_relation)
        ]

    def create_directories(self, app):
        """
        Creates directories for views, urls, and templates if they don't exist.
        """
        directories = [
            "views",
            "urls", 
            f"templates/{app.label}",
            f"templates/{app.label}/includes"
        ]
        
        for dir_name in directories:
            dir_path = Path(app.path) / dir_name
            dir_path.mkdir(parents=True, exist_ok=True)

    def create_init_files(self, app, model_names, models):
        """
        Creates __init__.py files in views and urls directories.
        """
        model_name_slugs = [
            f"{self.camel_to_slug(model_name)}_views" 
            for model_name in model_names
        ]
        model_names_dict = {
            self.camel_to_slug(model.__name__): 
            self.camel_to_slug(self.model_name_plural(model)) 
            for model in models
        }
        
        for folder_name in ["views", "urls"]:
            file_path = Path(app.path) / folder_name / "__init__.py"
            template_path = f"django_baker_deepseek/__init__{folder_name}"  # Fixed path
            self.create_file_from_template(
                file_path, 
                template_path, 
                {
                    "app_label": app.label,
                    "model_name_slugs": model_name_slugs,
                    "model_names_dict": model_names_dict
                }
            )
            

    def model_attributes(self, app, model):
        """
        Creates a dictionary of model attributes for template rendering.
        """
        model_name = model.__name__
        model_name_plural = self.model_name_plural(model)
        slug_field = self.get_unique_slug_field_name(model)
        slug_field_name = slug_field.name if slug_field else "pk"
        lookup_field = slug_field_name if slug_field else "pk"
        
        # Debug print to see what values we're getting
        # print(f"DEBUG: model_name={model_name}, model_name_slug={self.camel_to_slug(model_name)}")
        # print(f"DEBUG: model_name_plural={model_name_plural}, model_name_plural_slug={self.camel_to_slug(model_name_plural)}")
        
        return {
            'app_label': app.label,
            'app_path': app.path,
            'model': model,
            'model_name': model_name,
            'model_name_slug': self.camel_to_slug(model_name),  # This should be 'audit_entry'
            'model_name_plural': model_name_plural,
            'model_name_plural_slug': self.camel_to_slug(model_name_plural),
            'model_fields': self.get_field_names_for_model(model),
            'slug_field': slug_field,
            'slug_field_name': slug_field_name,
            'lookup_field': lookup_field
        }


    def create_file_from_template(self, file_path, template_path, context_variables):
        """
        Creates a file from a template with context variables.
        """
        file_path = Path(file_path)
        
        if file_path.exists() and not self.force:
            print(f"\033[91m{file_path} already exists. Skipping.\033[0m")
            return
            
        if self.dry_run:
            print(f"\033[93mWould create {file_path}\033[0m")
            return
            
        try:
            # For HTML templates, use simple string replacement to preserve Django template syntax
            if str(file_path).endswith('.html'):
                template_content = get_template(template_path).template.source
                rendered_content = self._render_html_template(template_content, context_variables)
            else:
                # For Python files, use normal template rendering
                rendered_content = get_template(template_path).render(context_variables)
        except Exception as e:
            print(f"\033[91mError rendering template {template_path}: {e}\033[0m")
            return
            
        # Ensure directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as new_file:
            new_file.write(rendered_content)
            print(f"\033[92mSuccessfully baked {file_path}\033[0m")

    def _render_html_template(self, template_content, context):
        """Simple token replacement for HTML templates."""
        # print("DEBUG: _render_html_template called!")
        rendered = template_content
        
        # Debug: show what context we're receiving
        # print(f"DEBUG HTML CONTEXT: {list(context.keys())}")
        # if 'model_name' in context:
        #     print(f"DEBUG: model_name = {context['model_name']}")
        # if 'model_name_plural' in context:
        #     print(f"DEBUG: model_name_plural = {context['model_name_plural']}")
        # if 'model_name_slug' in context:
        #     print(f"DEBUG: model_name_slug = {context['model_name_slug']}")
        
        # Get model name for model-specific tokens
        model_name = context.get('model_name', '')
        model_name_plural = context.get('model_name_plural', '')
        model_name_slug = context.get('model_name_slug', '')
        app_label = context.get('app_label', '')
        lookup_field = context.get('lookup_field', 'pk')
        
        # Create replacement map for ALL possible tokens
        replacement_map = {
            # Generic tokens
            'MODEL_NAME': model_name,
            'MODEL_NAME_PLURAL': model_name_plural,
            'MODEL_NAME_SLUG': model_name_slug,
            'APP_LABEL': app_label,
            'LOOKUP_FIELD': lookup_field,
            
            # Model-specific tokens (like CustomUser_PLURAL, AuditEntry_SLUG, etc.)
            f'{model_name}_PLURAL': model_name_plural,
            f'{model_name}_SLUG': model_name_slug,
        }
        
        # Debug: show replacement map
        # print(f"DEBUG REPLACEMENT MAP: {replacement_map}")
        
        # Replace tokens in the template
        for token, value in replacement_map.items():
            if token in rendered:
                rendered = rendered.replace(token, str(value))
                # print(f"DEBUG: Replaced {token} with {value}")
        
        # Handle model fields - replace first 3 fields as examples
        if 'model_fields' in context and isinstance(context['model_fields'], list):
            model_fields = context['model_fields']
            for i, field in enumerate(model_fields[:3], 1):
                field_token = f'MODEL_FIELD_{i}'
                if field_token in rendered:
                    rendered = rendered.replace(field_token, field)
                    # print(f"DEBUG: Replaced {field_token} with {field}")
        
        # Debug: show what the rendered content looks like
        # print(f"DEBUG RENDERED CONTENT (first 200 chars): {rendered[:200]}")
        
        return rendered

    def _render_template_string(self, template_string, context):
        """
        Simple template string renderer that handles basic variable substitution.
        """
        rendered = template_string
        for key, value in context.items():
            if isinstance(value, str):
                placeholder = '{{ ' + key + ' }}'
                rendered = rendered.replace(placeholder, value)
        return rendered

    
    def _write_file(self, file_path, content):
        """Helper method to write file content."""
        file_path = Path(file_path)
        
        if file_path.exists() and not self.force:
            print(f"\033[91m{file_path} already exists. Skipping.\033[0m")
            return
            
        if self.dry_run:
            print(f"\033[93mWould create {file_path}\033[0m")
            return
            
        # Ensure directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as new_file:
            new_file.write(content)
            print(f"\033[92mSuccessfully baked {file_path}\033[0m")    

######################################################################

    def create_files_from_templates(self, model_attributes):
        """
        Creates files from templates for views, URLs, and templates.
        """
        # Create the base template first (only if it doesn't exist)
        base_template_path = Path(model_attributes['app_path']) / "templates" / "base.html"
        if not base_template_path.exists():
            base_content = """<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{% block title %}{% endblock %}</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        {% block css %}{% endblock %}
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="/">{% block app_name %}{% endblock %}</a>
                {% block nav_extra %}{% endblock %}
            </div>
        </nav>

        <main class="container">
            {% block content %}
            {% endblock %}
        </main>

        <footer class="bg-light text-center py-3 mt-5">
            <div class="container">
                <p>&copy; {% now "Y" %} {% block footer_name %}{% endblock %}</p>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        {% block js %}{% endblock %}
    </body>
    </html>"""
            self._write_file(base_template_path, base_content)
        
        # Create view files
        for folder_name in ["views", "urls"]:
            file_path = (
                Path(model_attributes['app_path']) / 
                folder_name / 
                f"{model_attributes['model_name_slug']}_{folder_name}.py"
            )
            template_path = f"django_baker_deepseek/{folder_name}"  # Fixed path
            self.create_file_from_template(file_path, template_path, model_attributes)
        
        # Create template files
        template_files = ["list", "detail", "create", "update", "delete"]
        for file_name in template_files:
            file_path = (
                Path(model_attributes['app_path']) / 
                "templates" / 
                model_attributes['app_label'] / 
                f"{model_attributes['model_name_slug']}_{file_name}.html"
            )
            template_path = f"django_baker_deepseek/{file_name}.html"  # Fixed path
            self.create_file_from_template(file_path, template_path, model_attributes)


    def remove_empty_startapp_files(self, app):
        """
        Removes empty files created by startapp.
        """
        files_to_check = ["views.py", "admin.py", "tests.py"]
        
        for file_name in files_to_check:
            file_path = Path(app.path) / file_name
            if file_path.exists():
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    content = [line for line in lines if line.strip() and not line.strip().startswith('#')]
                    
                    if len(content) <= 2:
                        if not self.dry_run:
                            file_path.unlink()
                            print(f"\033[90mRemoved empty {file_path}\033[0m")
                        else:
                            print(f"\033[93mWould remove empty {file_path}\033[0m")

    def camel_to_slug(self, name):
        """
        Converts camel case to slug case.
        """
        # Ensure we're working with a string
        if not isinstance(name, str):
            name = str(name)
        
        # print(f"DEBUG camel_to_slug input: {name}")
        
        name = re.sub(r'([a-z])([A-Z])', r'\1_\2', name).lower()
        name = re.sub(r'[^a-z0-9_]', '_', name)
        
        # print(f"DEBUG camel_to_slug output: {name}")
        return name

    def model_name_plural(self, model):
        """
        Gets the pluralized version of a model name.
        """
        # Handle lazy translation objects by converting to string
        verbose_name_plural = getattr(model._meta, 'verbose_name_plural', None)
        if verbose_name_plural:
            # Convert lazy translation object to string
            verbose_name_plural = force_str(verbose_name_plural)
            if verbose_name_plural and verbose_name_plural != model._meta.verbose_name + 's':
                return verbose_name_plural
        
        # Default pluralization: add 's' to model name
        return f"{model.__name__}s"

    def get_unique_slug_field_name(self, model):
        """
        Returns the unique SlugField if exactly one exists, otherwise None.
        """
        slug_fields = []
        for field in model._meta.get_fields():
            if (isinstance(field, SlugField) and 
                hasattr(field, 'unique') and field.unique):
                slug_fields.append(field)
        
        return slug_fields[0] if len(slug_fields) == 1 else None
