from typing import Dict, List, Optional
from dataclasses import dataclass
from django.conf import settings

# Template engine configurations
TEMPLATE_ENGINES = {
    'bootstrap5': {
        'path': 'django_baker/bootstrap5/',
        'name': 'Bootstrap 5',
        'dependencies': ['django-bootstrap5'],
    },
    'tailwind': {
        'path': 'django_baker/tailwind/',
        'name': 'Tailwind CSS',
        'dependencies': ['django-tailwind'],
    },
    'basic': {
        'path': 'django_baker/basic/',
        'name': 'Basic HTML',
        'dependencies': [],
    }
}

@dataclass
class BakerConfig:
    """Configuration class for Django Baker."""
    template_engine: str = 'bootstrap5'
    auth_decorators: bool = True
    pagination: bool = True
    base_template: str = 'base.html'
    force_overwrite: bool = False
    dry_run: bool = False
    
    # Advanced options
    generate_forms: bool = True
    generate_admin: bool = True
    generate_views: bool = True
    generate_urls: bool = True
    generate_templates: bool = True
    
    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.template_engine not in TEMPLATE_ENGINES:
            raise ValueError(
                f"Invalid template engine: {self.template_engine}. "
                f"Available options: {list(TEMPLATE_ENGINES.keys())}"
            )
    
    @classmethod
    def from_settings(cls) -> 'BakerConfig':
        """Create configuration from Django settings."""
        baker_settings = getattr(settings, 'DJANGO_BAKER_CONFIG', {})
        
        return cls(
            template_engine=baker_settings.get('TEMPLATE_ENGINE', 'bootstrap5'),
            auth_decorators=baker_settings.get('AUTH_DECORATORS', True),
            pagination=baker_settings.get('PAGINATION', True),
            base_template=baker_settings.get('BASE_TEMPLATE', 'base.html'),
            force_overwrite=baker_settings.get('FORCE_OVERWRITE', False),
            dry_run=baker_settings.get('DRY_RUN', False),
            generate_forms=baker_settings.get('GENERATE_FORMS', True),
            generate_admin=baker_settings.get('GENERATE_ADMIN', True),
            generate_views=baker_settings.get('GENERATE_VIEWS', True),
            generate_urls=baker_settings.get('GENERATE_URLS', True),
            generate_templates=baker_settings.get('GENERATE_TEMPLATES', True),
        )

def get_default_config() -> BakerConfig:
    """Get default configuration."""
    return BakerConfig.from_settings()