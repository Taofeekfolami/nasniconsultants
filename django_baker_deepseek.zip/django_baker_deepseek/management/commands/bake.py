from django.core.management.base import BaseCommand, CommandError
from django.apps import apps
from django.core.exceptions import ImproperlyConfigured

from ...bakery import Baker


class Command(BaseCommand):
    help = (
        "Generates generic views (create, update, detail, list, and delete), "
        "URLs, forms, and admin for models in an app. Optionally can restrict "
        "which models are generated on a per-app basis.\n\n"
        "Example: python manage.py bake app_name:Model1,Model2"
    )

    def add_arguments(self, parser):
        parser.add_argument(
            'apps_and_models',
            nargs='+',
            help='App names with optional model specifications (app:model1,model2)'
        )
        parser.add_argument(
            '--force',
            action='store_true',
            help='Overwrite existing files without prompting'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be generated without creating files'
        )

    def handle(self, *args, **options):
        ingredients = self.parse_bake_options(options["apps_and_models"])
        baker = Baker(force=options['force'], dry_run=options['dry_run'])
        baker.bake(ingredients)

    def parse_bake_options(self, apps_and_models):
        """Parse command line options to determine what apps and models to bake."""
        apps_and_models_to_bake = {}
        for app_and_model in apps_and_models:
            app_and_model_names = app_and_model.split(':')
            app_label = app_and_model_names[0].strip()
            
            if len(app_and_model_names) == 2:
                selected_model_names = [name.strip() for name in app_and_model_names[1].split(",")]
            else:
                selected_model_names = None
                
            app, models = self.get_app_and_models(app_label, selected_model_names)
            apps_and_models_to_bake[app_label] = (models, app)
            
        return apps_and_models_to_bake

    def get_app_and_models(self, app_label, model_names):
        """Get the app and models when given app_label and model names."""
        try:
            app = apps.get_app_config(app_label)
        except LookupError:
            raise CommandError(
                f"{app_label} is not properly configured. "
                f"Did you remember to add {app_label} to settings.INSTALLED_APPS?"
            )

        models = self.get_selected_models(app, model_names)
        return (app, models)

    def get_selected_models(self, app, model_names):
        """Return models for a given app, filtered by model_names if provided."""
        if model_names:
            models = []
            for model_name in model_names:
                try:
                    model = app.get_model(model_name)
                    models.append(model)
                except LookupError:
                    self.stderr.write(
                        self.style.WARNING(f"Model {model_name} not found in {app.label}")
                    )
            return models
        else:
            return app.get_models()