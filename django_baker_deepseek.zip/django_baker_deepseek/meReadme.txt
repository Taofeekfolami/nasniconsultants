This package is a refinement of django_baker PyPi package done over 10 years ago.
I found it useful and decided to refine it,
I had immense assistance from Deepseek AI tool.
Hence, named it django_baker_deepseek. It is ready to use, just extract it into your 
project and use it . 
    INSTALLED_APPS =[
        ....,
        'django_baker_deepseek',
        .....,
    ]

I have decided to publish it on GitHub for anyone interested in baking a Django app 
from models.py. 

Please feel free to package and publish on PyPi .

Taofeek Oladiran Folami.
diranfolami@gmail.com, drfolami@nasniconsultants.com.
4 September 2005

