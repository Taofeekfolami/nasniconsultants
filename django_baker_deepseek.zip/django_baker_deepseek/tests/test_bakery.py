from django.test import TestCase
from django.apps import apps
from django_baker.bakery import Baker

class TestBaker(TestCase):
    def setUp(self):
        self.baker = Baker()
        
    def test_model_attributes_generation(self):
        """Test that model attributes are generated correctly."""
        model = apps.get_model('auth', 'User')
        attributes = self.baker.model_attributes(apps.get_app_config('auth'), model)
        
        self.assertEqual(attributes['model_name'], 'User')
        self.assertEqual(attributes['model_name_slug'], 'user')
        self.assertEqual(attributes['app_label'], 'auth')