
# === django_baker_gemini/admin_mixins.py ===
from django.contrib import admin
from django.db.models import ForeignKey, OneToOneField, CharField, TextField, BooleanField
from django.urls import reverse
from django.utils.html import format_html
from django.core.exceptions import FieldDoesNotExist
from functools import partial


def remove_dupes(seq):
    return list(dict.fromkeys(seq))


def is_foreignkey(field):
    return isinstance(field, (ForeignKey, OneToOneField))


class ExtendedModelAdminMixin:
    """Smart defaults for list_display, filters and search in Django 4.2+"""

    extra_list_display = []
    extra_list_filter = []
    extra_search_fields = []
    link_foreign_key_fields = True
    max_related_objects = 250
    list_all_select_related = True

    filter_by_internal_types = {"BooleanField"}  # NullBooleanField removed in modern Django
    search_by_field_types = (CharField, TextField)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if self.list_all_select_related:
            related = [f.name for f in self.model._meta.get_fields() if is_foreignkey(f)]
            if related:
                qs = qs.select_related(*related)
        return qs

    def get_list_display(self, request):
        list_display = list(super().get_list_display(request))
        if tuple(list_display) == ("__str__",):
            list_display = [f.name for f in self.model._meta.fields if f.name != "id"]
        list_display += list(self.extra_list_display)

        # turn FK fields into admin links (when not already link)
        links = set(self.list_display_links or [])
        resolved = []
        for name in list_display:
            try:
                field = self.model._meta.get_field(name)
                if self.link_foreign_key_fields and is_foreignkey(field) and name not in links:
                    resolved.append(partial(self._fk_link, field_name=name))
                else:
                    resolved.append(name)
            except FieldDoesNotExist:
                resolved.append(name)
        return remove_dupes(resolved)

    def get_list_filter(self, request):
        current = list(super().get_list_filter(request))
        auto = []
        for f in self.model._meta.fields:
            if (
                f.get_internal_type() in self.filter_by_internal_types
                or (getattr(f, "choices", None) and f.choices)
                or (is_foreignkey(f) and getattr(f.related_model.objects, "count", lambda: 0)() <= self.max_related_objects)
            ):
                auto.append(f.name)
        return remove_dupes(current + auto + list(self.extra_list_filter))

    def get_search_fields(self, request):
        current = list(super().get_search_fields(request))
        auto = [f.name for f in self.model._meta.fields if isinstance(f, self.search_by_field_types)]
        return remove_dupes(current + auto + list(self.extra_search_fields))

    # helpers
    def _fk_link(self, obj, field_name):
        target = getattr(obj, field_name, None)
        if not target:
            return "-"
        try:
            url = reverse(f"admin:{target._meta.app_label}_{target._meta.model_name}_change", args=[target.pk])
            return format_html('<a href="{}">{}</a>', url, str(target))
        except Exception:
            return str(target)

    _fk_link.short_description = "Link"

