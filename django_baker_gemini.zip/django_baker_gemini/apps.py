from django.apps import AppConfig


class DjangoBakerGeminiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_baker_gemini'
