# bakery.py
import os
import re
from django.db.models.fields import SlugField
from django.template.loader import get_template
from django.db.models import ForeignKey, OneToOneField
from django.utils.functional import Promise


class Baker:

    def __init__(self, overwrite=False, dry_run=False):
        """
        overwrite: if True, always overwrite files
        dry_run: if True, only show what would be baked, without writing
        """
        self.overwrite = overwrite
        self.dry_run = dry_run

    def bake(self, apps_and_models):
        for app_label, models_app in apps_and_models.items():
            models, app = models_app
            model_names_map = {
                model.__name__: self.get_field_names_for_model(model)
                for model in models
            }

            self.create_directories(app)
            self.create_init_files(app, models)
            self.remove_empty_startapp_files(app)

            # Shared files (forms, admin)
            for file_name in ["forms", "admin"]:
                file_path = os.path.join(app.path, f"{file_name}.py")
                template_path = f"django_baker_gemini/{file_name}.tpl"
                self._write_template(template_path, {"model_names": model_names_map, "app_label": app.label}, file_path)

            # Per-model files
            for model in models:
                model_attributes = self.model_attributes(app, model)
                self.create_files_from_templates(model_attributes)

    # ----------------------------------------------------------------------
    # Utilities
    # ----------------------------------------------------------------------
    def get_field_names_for_model(self, model):
        """Concrete editable fields, excluding PKs."""
        return [
            field.name for field in model._meta.get_fields()
            if field.concrete and not field.primary_key and field.editable
        ]

    def create_directories(self, app):
        for folder_name in ["views", "urls", f"templates/{app.label}"]:
            os.makedirs(os.path.join(app.path, folder_name), exist_ok=True)

    def create_init_files(self, app, models):
        model_name_slugs = [self.camel_to_slug(m.__name__) for m in models]
        model_names_dict = {
            self.camel_to_slug(m.__name__): self.camel_to_slug(self.model_name_plural(m))
            for m in models
        }
        for folder_name in ["views", "urls"]:
            file_path = os.path.join(app.path, folder_name, "__init__.py")
            template_path = f"django_baker_gemini/__init__{folder_name}.tpl"
            context = {
                "app_label": app.label,
                "model_name_slugs": model_name_slugs,
                "model_names_dict": model_names_dict
            }
            self._write_template(template_path, context, file_path, overwrite=True)

    def model_attributes(self, app, model):
        slug_field = self.get_unique_slug_field_name(model)
        slug_field_name = slug_field.name if slug_field else "slug"
        lookup_field = slug_field_name if slug_field else "pk"

        return {
            'app_label': app.label,
            'app_path': app.path,
            'model': model,
            'model_name': model.__name__,
            'model_name_slug': self.camel_to_slug(model.__name__),
            'model_name_plural': self.model_name_plural(model),
            'model_name_plural_slug': self.camel_to_slug(self.model_name_plural(model)),
            'model_fields': self.get_field_names_for_model(model),
            'slug_field': slug_field,
            'slug_field_name': slug_field_name,
            'lookup_field': lookup_field
        }

    def create_files_from_templates(self, attrs):
        """Per-model views, urls, and templates."""
        # Views & urls
        for folder_name in ["views", "urls"]:
            file_path = os.path.join(attrs['app_path'], folder_name, f"{attrs['model_name_slug']}_{folder_name}.py")
            template_path = f"django_baker_gemini/{folder_name}.tpl"
            self._write_template(template_path, attrs, file_path)

        # Templates
        for file_name in ["base", "list", "detail", "create", "update", "delete"]:
            file_path = os.path.join(
                attrs['app_path'], "templates", attrs['app_label'],
                f"{attrs['model_name_slug']}_{file_name}.html"
            )
            template_path = f"django_baker_gemini/{file_name}.html"
            self._write_template(template_path, attrs, file_path)

    # ----------------------------------------------------------------------
    # Template renderer
    # ----------------------------------------------------------------------
    def _write_template(self, template_name, context, output_path, overwrite=False):
        tpl = get_template(template_name)
        content = tpl.render(context)

        # Strip {% verbatim %} ... {% endverbatim %}
        content = re.sub(r"{% verbatim %}(.*?){% endverbatim %}", r"\1", content, flags=re.S)

        # Respect overwrite and dry_run flags
        if not (self.overwrite or overwrite) and os.path.exists(output_path):
            print(f"\033[91m{output_path} already exists. Skipping.\033[0m")
            return False

        if self.dry_run:
            print(f"\033[94m[DRY RUN] Would bake {output_path}\033[0m")
            return True

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"\033[92mSuccessfully baked {output_path}\033[0m")
        return True

    # def _write_template(self, template_name, context, output_path, overwrite=False):
    #     try:
    #         tpl = get_template(template_name)
    #         content = tpl.render(context)

    #         # Strip {% verbatim %} ... {% endverbatim %}
    #         content = re.sub(r"{% verbatim %}(.*?){% endverbatim %}", r"\1", content, flags=re.S)

    #         if not overwrite and os.path.exists(output_path):
    #             print(f"\033[91m{output_path} already exists. Skipping.\033[0m")
    #             return False

    #         os.makedirs(os.path.dirname(output_path), exist_ok=True)
    #         with open(output_path, "w", encoding="utf-8") as f:
    #             f.write(content)
    #         print(f"\033[92mSuccessfully baked {output_path}\033[0m")
    #         return True
    #     except Exception as e:
    #         print(f"\n\033[91mError: Failed to bake {output_path}\033[0m")
    #         print(f"\033[91mTemplate: {template_name}\033[0m")
    #         print(f"\033[91mError Details: {e}\033[0m")
    #         return False

    # ----------------------------------------------------------------------
    # Helpers
    # ----------------------------------------------------------------------
    def remove_empty_startapp_files(self, app):
        for file_name in ["views", "admin", "tests"]:
            file_path = os.path.join(app.path, f"{file_name}.py")
            if os.path.exists(file_path) and os.path.getsize(file_path) <= 100:
                with open(file_path, 'r') as f:
                    if len(f.readlines()) <= 4:
                        os.remove(file_path)

    def camel_to_slug(self, name):
        s1 = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', name)
        return re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


    def model_name_plural(self, model):
        # Get verbose_name_plural or default to ModelName + s
        verbose_plural = model._meta.verbose_name_plural or f"{model.__name__}s"
        
        # If it’s a lazy proxy (from gettext_lazy), convert to string
        if isinstance(verbose_plural, Promise):
            verbose_plural = str(verbose_plural)
        
        return verbose_plural

    def get_unique_slug_field_name(self, model):
        for field in model._meta.get_fields():
            if isinstance(field, SlugField) and field.unique:
                return field
        return None
