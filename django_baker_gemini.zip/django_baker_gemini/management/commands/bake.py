# === management/commands/bake_scaffold.py ===
from django.core.management.base import BaseCommand, CommandError
from django.core.exceptions import ImproperlyConfigured
from django.apps import apps
from pathlib import Path

from django_baker_gemini.bakery import Baker


class Command(BaseCommand):
    help = (
        "Generates generic views, urls, forms, and Bootstrap 5 templates for a Django app's models.\n"
        "Usage: python manage.py bake_scaffold appname[:ModelA,ModelB] [another_app[:ModelX]]\n"
        "Notes:\n - No Jinja dependency; pure Django templates.\n - Uses Bootstrap 5 and Bootstrap Icons."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "apps_and_models",
            nargs="+",
            help='Specify apps and models to bake, e.g., "blog:Post,Category" or just "blog"',
        )
        parser.add_argument(
            "--overwrite",
            action="store_true",
            help="Overwrite existing files if they already exist.",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be generated without writing files.",
        )

    def handle(self, *args, **options):
        try:
            ingredients = self.parse_bake_options(options["apps_and_models"]) 
            baker = Baker(overwrite=options["--overwrite"] if "--overwrite" in options else options["overwrite"], dry_run=options["dry_run"])  # normalize
            baker.bake(ingredients)
            if options["dry_run"]:
                self.stdout.write(self.style.WARNING("DRY RUN: No files were written."))
            self.stdout.write(self.style.SUCCESS("Successfully baked your Django application! 🍰"))
        except CommandError as e:
            raise CommandError(f"An error occurred during baking: {e}")

    def parse_bake_options(self, apps_and_models):
        apps_and_models_to_bake = {}
        for app_and_model in apps_and_models:
            app_and_model_names = app_and_model.split(":", 1)
            app_label = app_and_model_names[0]
            selected_model_names = None
            if len(app_and_model_names) == 2 and app_and_model_names[1].strip():
                selected_model_names = [name.strip() for name in app_and_model_names[1].split(",") if name.strip()]
            app, models = self.get_app_and_models(app_label, selected_model_names)
            apps_and_models_to_bake[app_label] = (models, app)
        return apps_and_models_to_bake

    def get_app_and_models(self, app_label, model_names):
        try:
            app = apps.get_app_config(app_label)
        except ImproperlyConfigured:
            raise CommandError(
                f"{app_label} is improperly configured. Did you add it to settings.INSTALLED_APPS?"
            )
        models = self.get_selected_models(app, model_names)
        return (app, models)

    def get_selected_models(self, app, model_names):
        if model_names:
            try:
                models = [app.get_model(model_name) for model_name in model_names]
                return models
            except LookupError as e:
                raise CommandError(
                    f"One or more of the models you entered for {app.label} are incorrect: {e}"
                )
        else:
            return list(app.get_models())

